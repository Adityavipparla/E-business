from quart import Quart
app = Quart("moviesnow-backend")
