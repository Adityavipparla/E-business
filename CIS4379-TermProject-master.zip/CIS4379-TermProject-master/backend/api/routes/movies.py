from sqlalchemy import text
from ..app import app
from ..database import engine

@app.route("/movies")
async def movies():
    movies = []
    with engine.connect() as conn:
        result = conn.execute(text("SELECT id, title, description, poster_url FROM movies"))
        for row in result:
            movies.append(dict(row._mapping))
    return movies

@app.route("/movies/<int:movieid>")
async def movie(movieid):
    with engine.connect() as conn:
        result = conn.execute(text("SELECT id, title, description, poster_url, genre, trailer_id, rating, runtime_minutes, release_date FROM movies WHERE id = :id"), { "id": movieid })
        movie_row = result.first()

        if not movie_row:
            return {"error":"not found"}, 404

        showings = []
        result = conn.execute(text("SELECT theater_id, time, type, time > CURRENT_TIMESTAMP() as available FROM showings WHERE time >= CURRENT_DATE() AND time <= CURRENT_DATE() + INTERVAL 8 DAY AND movie_id = :id ORDER BY time ASC"), { "id": movieid })
        for row in result:
            showings.append(dict(row._mapping))

        theaters = []
        if not len(showings) == 0:
            result = conn.execute(text("SELECT id, name, city, state, zip FROM theaters WHERE id IN :ids"), { "ids": list(set([showing["theater_id"] for showing in showings])) })
            for row in result:
                theaters.append(dict(row._mapping))

        return { "movie": dict(movie_row._mapping), "showings": showings, "theaters": theaters }