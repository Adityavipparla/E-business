from datetime import datetime
from quart import request
from sqlalchemy import text
import json
from ..app import app
from ..database import engine

@app.route("/theaters/<int:theaterid>/showing/<int:showingtime>")
async def showing(theaterid, showingtime):
    with engine.connect() as conn:
        showtime = datetime.utcfromtimestamp(int(showingtime)).strftime('%Y-%m-%d %H:%M:%S')
        result = conn.execute(text("SELECT theater_id, movie_id, time, type, time > CURRENT_TIMESTAMP() AS available FROM showings WHERE theater_id = :theaterid AND time = :time"), { "theaterid": theaterid, "time": str(showtime) })
        showing_row = result.first()

        if not showing_row:
            return {"error":"not found"}, 404

        result = conn.execute(text("SELECT id, title, poster_url FROM movies WHERE id = :id"), { "id": showing_row.movie_id })
        movie_row = result.first()

        result = conn.execute(text("SELECT id, name, ticket_price FROM theaters WHERE id = :id"), { "id": showing_row.theater_id })
        theater_row = result.first()

        seats = []
        result = conn.execute(text("SELECT id, row_number, column_number, price, (SELECT id FROM purchases p WHERE p.seat = s.id AND p.showing_movie = :movieid AND p.showing_time = :time) IS NULL AS available FROM seats s WHERE theater_id = :id"), { "id": showing_row.theater_id, "movieid": showing_row.movie_id, "time": str(showtime) })
        for row in result:
            seats.append(dict(row._mapping))

        return { "showing": dict(showing_row._mapping), "movie": dict(movie_row._mapping), "theater": dict(theater_row._mapping), "seats": seats }

@app.route("/theaters/<int:theaterid>/showing/<int:showingtime>/seat/<string:seatid>", methods=['POST'])
async def showing_purchase(theaterid, showingtime, seatid):
    data = await request.get_data()
    body = json.loads(data)
    with engine.connect() as conn:
        showtime = datetime.utcfromtimestamp(int(showingtime)).strftime('%Y-%m-%d %H:%M:%S')
        result = conn.execute(
            text("SELECT theater_id, movie_id, time, type, time > CURRENT_TIMESTAMP() AS available FROM showings WHERE theater_id = :theaterid AND time = :time"),
            { "theaterid": theaterid, "time": str(showtime) }
        )
        showing_row = result.first()

        if not showing_row:
            return {"error":"not found"}, 404

        result = conn.execute(
            text("INSERT INTO purchases (seater_name, email, showing_movie, showing_time, seat) VALUES (:name, :email, :movieid, :time, :seat)"),
            { "name": body["name"], "email": body["email"], "movieid": showing_row.movie_id, "time": str(showtime), "seat": seatid }
        )

        conn.commit()

        return { "id": result.lastrowid }