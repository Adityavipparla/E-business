from sqlalchemy import text
from ..app import app
from ..database import engine

@app.route("/theaters")
async def theaters():
    theaters = []
    with engine.connect() as conn:
        result = conn.execute(text("SELECT id, name, address, city, state, zip FROM theaters"))
        for row in result:
            theaters.append(dict(row._mapping))
    return theaters

@app.route("/theaters/<int:theaterid>")
async def theater(theaterid):
    with engine.connect() as conn:
        result = conn.execute(text("SELECT id, name, address, city, state, zip, phone_number FROM theaters WHERE id = :id"), { "id": theaterid })
        theater_row = result.first()

        if not theater_row:
            return {"error":"not found"}, 404

        showings = []
        result = conn.execute(text("SELECT movie_id, UNIX_TIMESTAMP(time) as time, type, time > CURRENT_TIMESTAMP() as available FROM showings WHERE time >= CURRENT_DATE() AND time <= CURRENT_DATE() + INTERVAL 8 DAY AND theater_id = :id ORDER BY time ASC"), { "id": theaterid })
        for row in result:
            showings.append(dict(row._mapping))

        movies = []
        if not len(showings) == 0:
            result = conn.execute(text("SELECT id, title, description, poster_url FROM movies WHERE id IN :ids"), { "ids": list(set([showing["movie_id"] for showing in showings])) })
            for row in result:
                movies.append(dict(row._mapping))

        return { "theater": dict(theater_row._mapping), "showings": showings, "movies": movies }