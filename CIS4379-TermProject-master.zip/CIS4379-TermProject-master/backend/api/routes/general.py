from ..app import app


@app.route("/")
async def index():
    return {"hello": "world"}
