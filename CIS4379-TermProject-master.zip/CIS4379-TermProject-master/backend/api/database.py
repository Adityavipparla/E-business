from sqlalchemy import create_engine

# https://docs.sqlalchemy.org/en/20/tutorial/dbapi_transactions.html
# https://docs.sqlalchemy.org/en/20/dialects/mysql.html
# mysql+pymysql://user:pass@localhost/dbname
# engine = create_engine("sqlite+pysqlite:///:memory:", echo=True)
engine = create_engine("mysql+mysqldb://moviesnow:movie_Password1@localhost:3306/moviesnow", echo=True)