# For aiohttp examples: https://pypi.org/project/aiohttp/

from dotenv import load_dotenv
load_dotenv()

from api.app import app
import api.routes.all_routes  # noqa: F401

if __name__ == "__main__":
    app.run()
