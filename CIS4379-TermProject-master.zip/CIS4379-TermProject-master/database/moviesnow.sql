-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 05, 2023 at 03:45 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moviesnow`
--

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` varchar(2048) NOT NULL,
  `poster_url` varchar(128) NOT NULL,
  `genre` varchar(256) DEFAULT NULL,
  `trailer_id` varchar(24) DEFAULT NULL,
  `rating` varchar(8) DEFAULT NULL,
  `runtime_minutes` int(11) DEFAULT NULL,
  `release_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `title`, `description`, `poster_url`, `genre`, `trailer_id`, `rating`, `runtime_minutes`, `release_date`) VALUES
(1, 'Barbie', 'To live in Barbie Land is to be a perfect being in a perfect place. Unless you have a full-on existential crisis. Or you\'re a Ken.', 'https://www.cinemark.com/media/76006925/lg-barbie-poster-2.jpg', 'Adventure, Comedy', 'pBk4NYhWNMM', 'PG-13', 114, '2023-07-31'),
(2, 'Five Nights at Freddy\'s', 'A troubled security guard begins working at Freddy Fazbear\'s Pizzeria. While spending his first night on the job, he realizes the late shift at Freddy\'s won\'t be so easy to make it through. Also streaming on Peacock.', 'https://www.cinemark.com/media/76008921/lg-five-nights-at-freddys-poster.jpg', 'Horror', 'Z_T0o5uNrlY', 'PG-13', 109, '2023-10-27'),
(3, 'Teenage Mutant Ninja Turtles: Mutant Mayhem', 'After years of being sheltered from the human world, the Turtle brothers set out to win the hearts of New Yorkers and be accepted as normal teenagers. Their new friend, April O\'Neil, helps them take on a mysterious crime syndicate, but they soon get in over their heads when an army of mutants is unleashed upon them.', 'https://www.cinemark.com/media/76009135/lg-tmntmm-final-poster.jpg', 'Children, Comedy, Adventure, Animated', 'JhXRNRmuYcc', 'PG', 100, '2023-08-04'),
(4, 'Wish', 'Walt Disney Animation Studios’ “Wish” is an all-new musical-comedy welcoming audiences to the magical kingdom of Rosas, where Asha, a sharp-witted idealist, makes a wish so powerful that it is answered by a cosmic force—a little ball of boundless energy called Star. Together, Asha and Star confront a most formidable foe—the ruler of Rosas, King Magnifico—to save her community and prove that when the will of one courageous human connects with the magic of the stars, wondrous things can happen.', 'https://www.cinemark.com/media/0pohjhgk/lg-wish-payoff-poster.jpg', 'Animation', 'oyRxxpD3yNw', 'PG', 95, '2023-11-22'),
(5, 'Trolls Band Together', 'This holiday season, get ready for an action-packed, all-star, rainbow-colored family reunion like no other as Anna Kendrick and Justin Timberlake return for the new chapter in DreamWorks Animation’s blockbuster musical franchise: Trolls Band Together. After two films of true friendship and relentless flirting, Poppy (Anna Kendrick) and Branch (Justin Timberlake) are now officially, finally, a couple (#broppy)! As they grow closer, Poppy discovers that Branch has a secret past. He was once part of her favorite boyband phenomenon, BroZone, with his four brothers: Floyd (Golden Globe nominated electropop sensation Troye Sivan), John Dory (Eric André; Sing 2), Spruce (Grammy winner Daveed Diggs; Hamilton) and Clay (Grammy winner Kid Cudi; Don’t Look Up). BroZone disbanded when Branch was still a baby, as did the family, and Branch hasn’t seen his brothers since. But when Branch’s bro Floyd is kidnapped for his musical talents by a pair of nefarious pop-star villains—Velvet (Emmy winner Amy Schumer; Trainwreck) and Veneer (Grammy winner and Tony nominee Andrew Rannells; The Book of Mormon)—Branch and Poppy embark on a harrowing and emotional journey to reunite the other brothers and rescue Floyd from a fate even worse than pop-culture obscurity.', 'https://www.cinemark.com/media/76011883/lg-trolls-new-poster.jpg', 'Animation, Family', 'ftUpFjGKuY0', 'PG', 91, '2023-11-17'),
(6, 'The Equalizer 3', 'Since giving up his life as a government assassin, Robert McCall (Denzel Washington) has struggled to reconcile the horrific things he’s done in the past and finds a strange solace in serving justice on behalf of the oppressed. Finding himself surprisingly at home in Southern Italy, he discovers his new friends are under the control of local crime bosses. As events turn deadly, McCall knows what he has to do: become his friends’ protector by taking on the mafia.', 'https://www.cinemark.com/media/76007859/lg-eq3-poster.jpg', 'Action', '0UJJ0DVSrsk', 'R', 109, '2023-09-01'),
(7, 'Oppenheimer', 'Written and directed by Christopher Nolan, Oppenheimer is an IMAX®-shot epic thriller that thrusts audiences into the pulse-pounding paradox of the enigmatic man who must risk destroying the world in order to save it. The film stars Cillian Murphy as J. Robert Oppenheimer and Emily Blunt as his wife, biologist and botanist Katherine “Kitty” Oppenheimer. Oscar® winner Matt Damon portrays General Leslie Groves Jr., director of the Manhattan Project, and Robert Downey, Jr. plays Lewis Strauss, a founding commissioner of the U.S. Atomic Energy Commission. Academy Award® nominee Florence Pugh plays psychiatrist Jean Tatlock, Benny Safdie plays theoretical physicist Edward Teller, Michael Angarano plays Robert Serber and Josh Hartnett plays pioneering American nuclear scientist Ernest Lawrence. Oppenheimer also stars Oscar® winner Rami Malek and reunites Nolan with eight-time Oscar® nominated actor, writer and filmmaker Kenneth Branagh. The cast includes Dane DeHaan (Valerian and the City of a Thousand Planets), Dylan Arnold (Halloween franchise), David Krumholtz (The Ballad of Buster Scruggs), Alden Ehrenreich (Solo: A Star Wars Story) and Matthew Modine (The Dark Knight Rises). The film is based on the Pulitzer Prize-winning book American Prometheus: The Triumph and Tragedy of J. Robert Oppenheimer by Kai Bird and the late Martin J. Sherwin. The film is produced by Emma Thomas, Atlas Entertainment’s Charles Roven and Christopher Nolan. Oppenheimer is filmed in a combination of IMAX® 65mm and 65mm large-format film photography including, for the first time ever, sections in IMAX® black and white analogue photography. Nolan’s films, including Tenet, Dunkirk, Interstellar, Inception and The Dark Knight trilogy, have earned more than $5 billion at the global box office and have been awarded 11 Oscars and 36 nominations, including two Best Picture nominations.', 'https://www.cinemark.com/media/76008374/lg-oppennheimer-new-poster.jpg', 'Epic Thriller', 'uYPbbksJxIg', 'R', 180, '2023-07-21'),
(8, 'Taylor Swift | The Eras Tour', 'The cultural phenomenon continues on the big screen! Immerse yourself in this once-in-a-lifetime concert film experience, which has a Rotten Tomatoes score of 100%, with a breathtaking, cinematic view of the history-making tour. Find movie showtimes at your theatre and grab tickets today! Taylor Swift Eras attire and friendship bracelets are strongly encouraged!', 'https://www.cinemark.com/media/76011410/lg_bts_poster.png', NULL, 'KudedLV0tP0', 'NR', 160, '2023-10-13'),
(9, 'Saw X', 'John Kramer (Tobin Bell) is back. The most chilling installment of the SAW franchise yet explores the untold chapter of Jigsaw’s most personal game. Set between the events of SAW I and II, a sick and desperate John travels to Mexico for a risky and experimental medical procedure in hopes of a miracle cure for his cancer – only to discover the entire operation is a scam to defraud the most vulnerable. Armed with a newfound purpose, John returns to his work, turning the tables on the con artists in his signature visceral way through a series of ingenious and terrifying traps.', 'https://www.cinemark.com/media/76010587/lg-saw-x-poster.jpg', 'Horror, Thriller', 't3PzUo4P21c', 'R', 118, '2023-09-29'),
(10, 'Thanksgiving', 'After a Black Friday riot ends in tragedy, a mysterious Thanksgiving-inspired killer terrorizes Plymouth, Massachusetts – the birthplace of the infamous holiday.', 'https://www.cinemark.com/media/yufmjwih/lg-thanksgiving-new-poster.jpg', 'Horror', NULL, NULL, 106, '2023-11-17'),
(11, 'Dumb Money', 'Dumb Money is the ultimate David vs. Goliath tale, based on the insane true story of everyday people who flipped the script on Wall Street and got rich by turning GameStop (yes, the mall videogame store) into the world’s hottest company. In the middle of everything is regular guy Keith Gill (Paul Dano), who starts it all by sinking his life savings into the stock and posting about it. When his social posts start blowing up, so does his life and the lives of everyone following him. As a stock tip becomes a movement, everyone gets rich – until the billionaires fight back, and both sides find their worlds turned upside down. Dumb Money also stars Pete Davidson, Vincent D’Onofrio, America Ferrera, Nick Offerman, Anthony Ramos, Sebastian Stan, Shailene Woodley and Seth Rogen. Directed by Craig Gillespie, written by Lauren Schuker Blum & Rebecca Angelo, based on the book “The Antisocial Network” by Ben Mezrich.', 'https://www.cinemark.com/media/zrupbxnl/lg-nn-dumb-money-poster.jpg', 'Comedy, Drama', 'tO2Rl51g1H8', 'R', 105, '2023-09-22'),
(12, 'The Marvels', 'Carol Danvers aka Captain Marvel has reclaimed her identity from the tyrannical Kree and taken revenge on the Supreme Intelligence. But unintended consequences see Carol shouldering the burden of a destabilized universe. When her duties send her to an anomalous wormhole linked to a Kree revolutionary, her powers become entangled with that of Jersey City super-fan, Kamala Khan aka Ms. Marvel, and Carol’s estranged niece, now S.A.B.E.R. astronaut Captain Monica Rambeau. Together, this unlikely trio must team-up and learn to work in concert to save the universe as “The Marvels.”', 'https://www.cinemark.com/media/76010473/lg-the-marvels-new-poster.jpg', 'Action', 'wS_qbDztgVY', 'PG-13', 105, '2023-11-10');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `seater_name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `showing_movie` int(11) NOT NULL,
  `showing_time` datetime NOT NULL,
  `seat` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `seater_name`, `email`, `showing_movie`, `showing_time`, `seat`) VALUES
(2, 'John Doe', 'john@gmail.com', 2, '2023-10-28 18:00:00', 'A1'),
(3, 'John Doe', 'john@email.com', 2, '2023-12-08 19:00:00', 'A1');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id` varchar(4) NOT NULL,
  `theater_id` int(11) NOT NULL,
  `row_number` int(11) NOT NULL,
  `column_number` int(11) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`id`, `theater_id`, `row_number`, `column_number`, `price`) VALUES
('A1', 1, 0, 11, NULL),
('A10', 1, 0, 2, NULL),
('A11', 1, 0, 1, NULL),
('A12', 1, 0, 0, NULL),
('A2', 1, 0, 10, NULL),
('A3', 1, 0, 9, NULL),
('A4', 1, 0, 8, NULL),
('A5', 1, 0, 7, NULL),
('A6', 1, 0, 6, NULL),
('A7', 1, 0, 5, NULL),
('A8', 1, 0, 4, NULL),
('A9', 1, 0, 3, NULL),
('B1', 1, 1, 11, NULL),
('B10', 1, 1, 2, NULL),
('B11', 1, 1, 1, NULL),
('B12', 1, 1, 0, NULL),
('B2', 1, 1, 10, NULL),
('B3', 1, 1, 9, NULL),
('B4', 1, 1, 8, NULL),
('B5', 1, 1, 7, NULL),
('B6', 1, 1, 6, NULL),
('B7', 1, 1, 5, NULL),
('B8', 1, 1, 4, NULL),
('B9', 1, 1, 3, NULL),
('C10', 1, 3, 2, NULL),
('C11', 1, 3, 1, NULL),
('C2', 1, 3, 10, NULL),
('C3', 1, 3, 9, NULL),
('C4', 1, 3, 8, NULL),
('C5', 1, 3, 7, NULL),
('C6', 1, 3, 6, NULL),
('C7', 1, 3, 5, NULL),
('C8', 1, 3, 4, NULL),
('C9', 1, 3, 3, NULL),
('D10', 1, 4, 2, NULL),
('D11', 1, 4, 1, NULL),
('D12', 1, 4, 0, NULL),
('D2', 1, 4, 10, NULL),
('D3', 1, 4, 9, NULL),
('D4', 1, 4, 8, NULL),
('D5', 1, 4, 7, NULL),
('D6', 1, 4, 6, NULL),
('D7', 1, 4, 5, NULL),
('D8', 1, 4, 4, NULL),
('D9', 1, 4, 3, NULL),
('E10', 1, 5, 2, NULL),
('E11', 1, 5, 1, NULL),
('E12', 1, 5, 0, NULL),
('E2', 1, 5, 10, NULL),
('E3', 1, 5, 9, NULL),
('E4', 1, 5, 8, NULL),
('E5', 1, 5, 7, NULL),
('E6', 1, 5, 6, NULL),
('E7', 1, 5, 5, NULL),
('E8', 1, 5, 4, NULL),
('E9', 1, 5, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `showings`
--

CREATE TABLE `showings` (
  `movie_id` int(11) NOT NULL,
  `theater_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `type` varchar(64) NOT NULL DEFAULT 'regular'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `showings`
--

INSERT INTO `showings` (`movie_id`, `theater_id`, `time`, `type`) VALUES
(1, 1, '2023-10-24 17:00:00', 'regular'),
(2, 1, '2023-10-28 18:00:00', 'regular'),
(2, 1, '2023-10-30 09:30:00', 'regular'),
(2, 1, '2023-10-30 21:30:00', 'regular'),
(2, 1, '2023-10-30 22:55:00', 'imax'),
(2, 1, '2023-10-30 23:00:00', '3d'),
(2, 1, '2023-12-08 19:00:00', 'regular');

-- --------------------------------------------------------

--
-- Table structure for table `theaters`
--

CREATE TABLE `theaters` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `city` varchar(128) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zip` int(11) NOT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `ticket_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `theaters`
--

INSERT INTO `theaters` (`id`, `name`, `address`, `city`, `state`, `zip`, `phone_number`, `ticket_price`) VALUES
(1, 'Cinemark Harker Heights', '201 E Central Texas Expy, Suite 100', 'Harker Heights', 'TX', 76548, '2546904581', '11.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `showing_seat` (`showing_movie`,`showing_time`,`seat`),
  ADD KEY `seat` (`seat`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id`,`theater_id`),
  ADD UNIQUE KEY `position` (`row_number`,`column_number`) USING BTREE,
  ADD KEY `theater_id` (`theater_id`);

--
-- Indexes for table `showings`
--
ALTER TABLE `showings`
  ADD PRIMARY KEY (`movie_id`,`time`) USING BTREE,
  ADD KEY `theater_id` (`theater_id`),
  ADD KEY `movie_id` (`movie_id`),
  ADD KEY `time` (`time`);

--
-- Indexes for table `theaters`
--
ALTER TABLE `theaters`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `theaters`
--
ALTER TABLE `theaters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`seat`) REFERENCES `seats` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `showing` FOREIGN KEY (`showing_movie`,`showing_time`) REFERENCES `showings` (`movie_id`, `time`) ON DELETE CASCADE;

--
-- Constraints for table `seats`
--
ALTER TABLE `seats`
  ADD CONSTRAINT `seats_ibfk_1` FOREIGN KEY (`theater_id`) REFERENCES `theaters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `showings`
--
ALTER TABLE `showings`
  ADD CONSTRAINT `showings_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `showings_ibfk_2` FOREIGN KEY (`theater_id`) REFERENCES `theaters` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
